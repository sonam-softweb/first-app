class ReceivedBorrowerPayment < ActiveRecord::Base
	belongs_to :borrower
end
