class DueBorrowerPayment < ActiveRecord::Base
	belongs_to :borrower
end
