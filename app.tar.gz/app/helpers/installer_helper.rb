module InstallerHelper
end
