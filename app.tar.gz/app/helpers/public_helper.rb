module PublicHelper
  # basically we need an Even number to add a space before it does it's next thing
  def div_start
    
  end

  def div_end
    
  end
end


	# <div class="round-corners fivecol last" id="projects">
	#   <h1>Jimmy's' School Project</h1>
	#   <div class="image sixcol">
	#     <%= image_tag('/images/solars.jpg') %>
	#     <div class="text">
	#       <p>20 Days</p>
	#       <h2>50% Funded</h2>
	#     </div>
	#   </div>
	#   <div class="project-text sixcol last">
	#     <h2>Location: El Segundo, CA</h2>
	#     <h3>System Size: 5 KW</h3>

      #       <p>12 Bids</p>
      #         <h2>$5000 Needed</h2>
      #     </div>
      #   </div>
      # </section>
      # <section class="row">
      #   <div class="round-corners fivecol" id="projects">
      #     <h1>Let Jesus Shine on our Church Solar</h1>
      #     <div class="image sixcol">
      #       <%= image_tag('/images/solars.jpg') %>
      #       <div class="text">
      #         <p>30 Days</p>
      #         <h2>20% Funded</h2>
      #       </div>
      #     </div>
      #     <div class="project-text sixcol last">
      #       <h2>Location: Ontario, CA</h2>
      #       <h3>System Size: 5 KW</h3>
	#     <p>3 Bids</p>
	#       <h2>$2000 Needed</h2>
	#   </div>
	# </div>
	# <div class="onecol">
	# </div>
	# <div class="round-corners fivecol last" id="projects">
	#   <h1>Ralf Malf's Homeage to the Sun</h1>
	#   <div class="image sixcol">
	#     <%= image_tag('/images/solars.jpg') %>
	#     <div class="text">
	#       <p>2 Days</p>
	#       <h2>5% Funded</h2>
	#     </div>
	#   </div>
	#   <div class="project-text sixcol last">
	#     <h2>Location: Beverly Hills, CA</h2>
	#     <h3>System Size: 5 KW</h3>
	#     <p>1 Bid</p>
	#       <h2>$50000 Needed</h2>
	#   </div>
	# </div>
